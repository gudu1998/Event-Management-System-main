import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../services/user.service';
import { catchError, of, takeWhile } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  signUpForm: FormGroup;
  signUpActionisActive: boolean = true;
  error:boolean = false;
  errorMessage:any;

  constructor(private fb: FormBuilder,private user: UserService,private router:Router) {
    this.signUpForm = this.fb.group({
      FullName: null,
      UserName: null,
      Biography: null,
      Branch: null,
      College: null,
      Email: null,
      Age: null,
      Address: null,
      City: null,
      State: null,
      Country: null,
      Mobile: null,
      BatchYear: null,
      Password: null,
    })
  }

  ngOnInit(): void {
  }

  createAlumini() {
  this.user.createUser(this.signUpForm.value.FullName,this.signUpForm.value.UserName,this.signUpForm.value.Biography,
    this.signUpForm.value.Branch,this.signUpForm.value.College,this.signUpForm.value.Email,
    this.signUpForm.value.Age,this.signUpForm.value.Address,this.signUpForm.value.City,
    this.signUpForm.value.State,this.signUpForm.value.Country,this.signUpForm.value.Mobile,
    this.signUpForm.value.BatchYear,this.signUpForm.value.Password)
    .pipe(catchError(e => of(e.error)))
    .subscribe(res => {
      if(res.status == 401 || res.status == 400){
        this.error=true;
        this.errorMessage = res.message
      }
      else
      this.router.navigate(['/user/signin'])   
  })
  }

  ngOnDestroy() {
    this.signUpActionisActive = false
  }

}

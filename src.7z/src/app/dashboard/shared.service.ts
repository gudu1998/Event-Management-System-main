import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http'
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class SharedService {
  private baseUrl = 'http://localhost:5000';
  constructor(private http: HttpClient) { }

  createNewNotice(noticeTitle: String, noticeDescription: String, noticeDate: Date): Observable<any> {
    const noticeData = { noticeTitle, noticeDescription, noticeDate };

    return this.http.post(this.baseUrl + '/createNotice', noticeData);
  }

  showNotice(): Observable<any> {
    return this.http.get(this.baseUrl + '/showNotice');
  }

  postJobOpening(jobTitle: String, jobName: String, jobWebsite: String, jobLocation: String,
    jobArea: String,skills: String, salary: String): Observable<any> {

    const jobData = {
      jobTitle, jobName, jobWebsite,
      jobLocation, jobArea,skills,salary
    };

    return this.http.post(this.baseUrl + '/createJob', jobData);
  }

  showJob(): Observable<any> {
    return this.http.get(this.baseUrl + '/showJob');
  }

  getDistinctJob(): Observable<any> {
    return this.http.get(this.baseUrl + '/getDistinctJob');
  }

  filterJobByLocation(filterData:any):  Observable<any>{
    
    return this.http.post(this.baseUrl + '/filterJobByLocation',filterData);
  }

  filterJobByName(filterData:any):  Observable<any>{
    
    return this.http.post(this.baseUrl + '/filterJobByName',filterData);
  }

  filterJobByArea(filterData:any):  Observable<any>{
    
    return this.http.post(this.baseUrl + '/filterJobByArea',filterData);
  }

  filterJobBySkills(filterData:any):  Observable<any>{
    
    return this.http.post(this.baseUrl + '/filterJobBySkills',filterData);
  }
  
  createNewEvent(eventType: String, eventCategory: String, eventName: String, eventDescription: String,
    eventUrl: String, eventDate: Date, eventTime: String, eventAmPm: String, eventTimeZone: String
    , imagePath: File): Observable<any> {

    const eventData: any = new FormData();

    eventData.append("eventType", eventType);
    eventData.append("eventCategory", eventCategory);
    eventData.append("eventName", eventName);
    eventData.append("eventDescription", eventDescription);
    eventData.append("eventUrl", eventUrl);
    eventData.append("eventDate", eventDate);
    eventData.append("eventTime", eventTime);
    eventData.append("eventAmPm", eventAmPm);
    eventData.append("eventTimeZone", eventTimeZone);
    eventData.append("imagePath", imagePath);

    console.log(eventData)

    return this.http.post(this.baseUrl + '/createEvent', eventData);
  }

  showEvent(): Observable<any> {
    return this.http.get(this.baseUrl + '/showEvent');
  }

  getEventDetails(id: any): Observable<any> {
    let queryParams = new HttpParams();
    queryParams = queryParams.append("_id", id);
    return this.http.get(this.baseUrl + '/getEventDetail', { params: queryParams });
  }

  showAlumini(): Observable<any> {
    return this.http.get(this.baseUrl + '/showAlumini');
  }

  findAlumini(fullName?:String,college?:String,branch?:String,batch?:Number) : Observable<any>{
    // let queryParams:any = new HttpParams();
    // queryParams = queryParams.append("fullName", fullName);
    // queryParams = queryParams.append("college", college);
    // queryParams = queryParams.append("branch", branch);
    // queryParams = queryParams.append("batch", batch);
    const  searchData = {fullName,college,branch,batch} 
    return this.http.post(this.baseUrl + '/findAlumini', searchData)
  }

  loginAlumini(userName:String, mobile:Number, password:String){
    const loginData = {userName,mobile,password};
    return this.http.post(this.baseUrl + '/loginAlumini', loginData);
  }
}

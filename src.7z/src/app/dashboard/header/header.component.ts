import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  searchForm!: FormGroup;
  constructor(private fb: FormBuilder,private shared:SharedService,private router:Router) {
    this.searchForm = this.fb.group({
      Search: [null, [Validators.required]]
    })
   }

  ngOnInit(): void {
  }

  searchAlumini(){
    this.shared.findAlumini(this.searchForm.value.Search).subscribe(res => {
        this.router.navigate(['/user/search',this.searchForm.value.Search])
        console.log(res)
    });
  }
}

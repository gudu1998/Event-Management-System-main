import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAluminiByBranchNameBatchCollegeComponent } from './get-alumini-by-branch-name-batch-college.component';

describe('GetAluminiByBranchNameBatchCollegeComponent', () => {
  let component: GetAluminiByBranchNameBatchCollegeComponent;
  let fixture: ComponentFixture<GetAluminiByBranchNameBatchCollegeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetAluminiByBranchNameBatchCollegeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetAluminiByBranchNameBatchCollegeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

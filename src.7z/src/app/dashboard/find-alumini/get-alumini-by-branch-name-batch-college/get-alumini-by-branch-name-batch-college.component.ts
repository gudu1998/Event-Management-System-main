import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from '../../shared.service';

@Component({
  selector: 'app-get-alumini-by-branch-name-batch-college',
  templateUrl: './get-alumini-by-branch-name-batch-college.component.html',
  styleUrls: ['./get-alumini-by-branch-name-batch-college.component.css']
})
export class GetAluminiByBranchNameBatchCollegeComponent implements OnInit {
 searchAlumini:any
  constructor(private route: ActivatedRoute,private shared:SharedService) { }

  ngOnInit(): void {
  //   const {id} = this.route.snapshot.params;
  //   this.shared.getEventDetails(id).subscribe(res => {
  //    this.searchAlumini=res.result;
  //  });
  }

}

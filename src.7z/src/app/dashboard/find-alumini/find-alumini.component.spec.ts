import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FindAluminiComponent } from './find-alumini.component';

describe('FindAluminiComponent', () => {
  let component: FindAluminiComponent;
  let fixture: ComponentFixture<FindAluminiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FindAluminiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FindAluminiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

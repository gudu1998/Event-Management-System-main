import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-find-alumini',
  templateUrl: './find-alumini.component.html',
  styleUrls: ['./find-alumini.component.css']
})
export class FindAluminiComponent implements OnInit {
  findAluminiForm!: FormGroup;
  aluminiDetail:any
  Fullname:any
  constructor(private fb: FormBuilder,private shared:SharedService,private router:Router) { 
    this.findAluminiForm = this.fb.group({
      Fullname: [null],
      College: [null],
      Branch: [null],
      Batch: [null]
    })
  }

  ngOnInit(): void {
  }

  findAlumini(){
    this.shared.findAlumini(this.findAluminiForm.value.Fullname,this.findAluminiForm.value.College,
      this.findAluminiForm.value.Branch,this.findAluminiForm.value.Batch).subscribe(res => {
  this.Fullname = this.findAluminiForm.value.Fullname ? this.findAluminiForm.value.Fullname : 'gg';
console.log(this.Fullname)
        this.router.navigate(['/user/search',this.Fullname,this.findAluminiForm.value.College,
        this.findAluminiForm.value.Branch,this.findAluminiForm.value.Batch])
        // console.log(res)
    });
     
  }
}

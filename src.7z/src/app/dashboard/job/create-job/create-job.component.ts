import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SharedService } from '../../shared.service';
import { takeWhile } from 'rxjs';

@Component({
  selector: 'app-create-job',
  templateUrl: './create-job.component.html',
  styleUrls: ['./create-job.component.css']
})
export class CreateJobComponent implements OnInit {
  jobForm!: FormGroup;
  jobType = ['Fulltime', 'Intern'];

  jobPosition = ['Software Developer', 'IT Positions', 'Brand Ambassador',
    'Machine Learning Engineer', 'Full Stack Developer'];

  jobActionIsActive: boolean = true;

  constructor(private fb: FormBuilder, private shared: SharedService, private router: Router) {
    // this.jobForm = this.fb.group({
    //   Type: [null, [Validators.required]],
    //   Position: [null, [Validators.required]],
    //   Url: [null, [Validators.required]],
    //   Description: [null, [Validators.required]],
    //   Date: [null, [Validators.required]]
    // })

    this.jobForm = this.fb.group({
      Title: [null, [Validators.required]],
      Name: [null, [Validators.required]],
      Website: null,
      Location: [null, [Validators.required]],
      JobArea: [null, [Validators.required]],
      Skills: [null, [Validators.required]],
      Salary: [null, [Validators.required]],
    })
  }

  ngOnInit(): void {
  }

  createJob() {
    this.shared.postJobOpening(this.jobForm.value.Title, this.jobForm.value.Name, 
      this.jobForm.value.Website, this.jobForm.value.Location, this.jobForm.value.JobArea,
      this.jobForm.value.Skills, this.jobForm.value.Salary)
      .pipe(takeWhile(() => this.jobActionIsActive)).subscribe(result => {
        this.router.navigate(['/user/newjob'])
      })
  }

  ngOnDestroy() {
    this.jobActionIsActive = false
  }

}

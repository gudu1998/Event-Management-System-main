import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { takeWhile } from 'rxjs';
import {  PrimeNGConfig } from "primeng/api";

@Component({
  selector: 'app-job',
  templateUrl: './job.component.html',
  styleUrls: ['./job.component.css']
})
export class JobComponent implements OnInit {
  jobArray!: any;
  jobArray1: any
  skills: any;
  jobLocation: any;
  jobName: any;
  jobArea: any;
  pageNumber: any = 1;
  count: any = 3;
  jobActionIsActive: boolean = true;
  userName: any = [];
  userName1: any = [];
  selectedJobLocation: any = [];
  selectedJobName: any = [];
  selectedJobArea: any = [];
  selectedSkills: any = [];
  totalRecords:any;
  rows:any =2;
  location = { locationArray: [] }
  loading:boolean=false
  constructor(private shared: SharedService, private primengConfig: PrimeNGConfig) {
  }
  data: any;

  ngOnInit(): void {
    // this.primengConfig.ripple = true;
    this.shared.showJob().pipe(takeWhile(() => this.jobActionIsActive)).subscribe(res => {
      this.totalRecords = res.result.length
      this.jobArray = res.result;
      this.jobArray1 = res.result;
      this.jobArray = this.jobArray1.slice(0,this.rows);
    })

    this.shared.getDistinctJob().pipe(takeWhile(() => this.jobActionIsActive)).subscribe(res => {
      this.jobLocation = res.result.jobLocation;
      this.jobName = res.result.jobName;
      this.jobArea = res.result.jobArea;
      this.skills = res.result.skills;
    })
  }

getRecordsByFilter(selectedJobLocation:any){
  this.userName = [];
  this.location.locationArray = [];
  if (selectedJobLocation.length > 1) {
    selectedJobLocation.map((item: any) => {
      item = item.value
      this.userName.push(item)
    })
  }
  else {
    this.userName.push(selectedJobLocation[0].value)

  }
  this.location.locationArray = this.userName
  
}
  selectedJobLocationValue() {
   this.getRecordsByFilter(this.selectedJobLocation);

   this.shared.filterJobByLocation(this.location).pipe(takeWhile(() => this.jobActionIsActive)).subscribe(res => {
    this.jobArray = res.result;
  })
  }

  selectedJobNameValue() {
    this.getRecordsByFilter(this.selectedJobName);

    this.shared.filterJobByName(this.location).pipe(takeWhile(() => this.jobActionIsActive)).subscribe(res => {
      this.jobArray = res.result;
    })
   }

   selectedJobAreaValue() {
    this.getRecordsByFilter(this.selectedJobArea);

    this.shared.filterJobByArea(this.location).pipe(takeWhile(() => this.jobActionIsActive)).subscribe(res => {
      this.jobArray = res.result;
    })
   }

   selectedSkillsValue() {
    this.getRecordsByFilter(this.selectedSkills);

    this.shared.filterJobBySkills(this.location).pipe(takeWhile(() => this.jobActionIsActive)).subscribe(res => {
      this.jobArray = res.result;
    })
   }
   paginate(event:any) {
    this.jobArray = this.jobArray1.slice(event.first, event.first+event.rows);
 }

  ngOnDestroy() {
    this.jobActionIsActive = false
  }
}

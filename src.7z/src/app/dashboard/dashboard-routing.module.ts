import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateEventComponent } from './events/create-event/create-event.component';
import { EventDetailComponent } from './events/event-detail/event-detail.component';
import { EventsComponent } from './events/events.component';
import { FindAluminiComponent } from './find-alumini/find-alumini.component';
import { GetAluminiByBranchNameBatchCollegeComponent } from './find-alumini/get-alumini-by-branch-name-batch-college/get-alumini-by-branch-name-batch-college.component';
import { HomeComponent } from './home/home.component';
import { CreateJobComponent } from './job/create-job/create-job.component';
import { JobComponent } from './job/job.component';
import { FindAluminiByFullNameComponent } from './list-of-alumini/find-alumini-by-full-name/find-alumini-by-full-name.component';
import { ListOfAluminiComponent } from './list-of-alumini/list-of-alumini.component';
import { CreateNoticeComponent } from './notice/create-notice/create-notice.component';
import { NoticeComponent } from './notice/notice.component';



const routes: Routes = [
  { path: 'create-event', component: CreateEventComponent },
  { path: 'events', component: EventsComponent },
  { path: 'eventdetail/:id', component: EventDetailComponent },
  { path: 'create-notice', component: CreateNoticeComponent },
  { path: 'notice', component: NoticeComponent },
  { path: 'create-job', component: CreateJobComponent },
  { path: 'newjob', component: JobComponent },
  { path: 'find-alumini', component: FindAluminiComponent },
  { path: 'alumini', component: ListOfAluminiComponent },
  { path: 'search/:fullName/:college/:branch/:batch', component: GetAluminiByBranchNameBatchCollegeComponent },
  { path: 'search/:fullName', component: FindAluminiByFullNameComponent },
  { path: 'home', component: HomeComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }

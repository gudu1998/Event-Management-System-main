import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-college-campus',
  templateUrl: './college-campus.component.html',
  styleUrls: ['./college-campus.component.css']
})
export class CollegeCampusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

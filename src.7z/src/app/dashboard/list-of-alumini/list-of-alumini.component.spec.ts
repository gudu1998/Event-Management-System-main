import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListOfAluminiComponent } from './list-of-alumini.component';

describe('ListOfAluminiComponent', () => {
  let component: ListOfAluminiComponent;
  let fixture: ComponentFixture<ListOfAluminiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListOfAluminiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListOfAluminiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

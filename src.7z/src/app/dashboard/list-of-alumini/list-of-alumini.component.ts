import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { takeWhile } from 'rxjs';

@Component({
  selector: 'app-list-of-alumini',
  templateUrl: './list-of-alumini.component.html',
  styleUrls: ['./list-of-alumini.component.css']
})
export class ListOfAluminiComponent implements OnInit {
  aluminiArray:any;
  pageNumber: any = 1;
  count: any = 3;
  aluminiActionIsActive:boolean = true;
  constructor(private shared:SharedService) { }

  ngOnInit(): void {
    this.shared.showAlumini().pipe(takeWhile(() => this.aluminiActionIsActive)).subscribe(res=>{
      this.aluminiArray = res.result;
      console.log(res)
       })
  }

  ngOnDestroy() {
    this.aluminiActionIsActive = false
  }

}

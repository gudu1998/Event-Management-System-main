import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from '../../shared.service';
import { takeWhile } from 'rxjs';

@Component({
  selector: 'app-find-alumini-by-full-name',
  templateUrl: './find-alumini-by-full-name.component.html',
  styleUrls: ['./find-alumini-by-full-name.component.css']
})
export class FindAluminiByFullNameComponent implements OnInit {
  searchAlumini:any
  aluminiActionIsActive:boolean = true;
  
  constructor(private route: ActivatedRoute,private shared:SharedService) { }

  ngOnInit(): void {
        const {fullName} = this.route.snapshot.params;
    this.shared.findAlumini(fullName).pipe(takeWhile(() => this.aluminiActionIsActive)).subscribe(res => {
     this.searchAlumini=res;
     console.log(res)
   });
  }
  ngOnDestroy() {
    this.aluminiActionIsActive = false
  }
}

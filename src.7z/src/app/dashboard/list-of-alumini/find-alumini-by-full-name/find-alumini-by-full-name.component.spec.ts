import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FindAluminiByFullNameComponent } from './find-alumini-by-full-name.component';

describe('FindAluminiByFullNameComponent', () => {
  let component: FindAluminiByFullNameComponent;
  let fixture: ComponentFixture<FindAluminiByFullNameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FindAluminiByFullNameComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FindAluminiByFullNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

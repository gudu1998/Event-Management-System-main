import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }
  
  images= [  
    { img: "../../../assets/images/01.JPG" },  
    { img: "../../../assets/images/02.jpg" },  
    { img: "../../../assets/images/Academic4.jpg" },  
    { img: "../../../assets/images/cet-bhubaneswar.png" },  
    { img: "../../../assets/images/main_gate.jpg" },  
    { img: "../../../assets/images/campus.png" },   
  ];  
  ngOnInit(): void {
  }

  slideConfig = {  
    "slidesToShow": 3,  
    "slidesToScroll": 3,  
    "dots": true,  
    "infinite":true 
  };

//   imgCollection: Array<object> = [
//     {
//       image: 'https://loremflickr.com/g/600/400/paris',
//     
//       alt: 'Image 1',
//       title: 'Image 1'
//     }, {
//       image: 'https://loremflickr.com/600/400/brazil,rio',
//       thumbImage: 'https://loremflickr.com/1200/800/brazil,rio',
//       title: 'Image 2',
//       alt: 'Image 2'
//     }, {
//       image: 'https://loremflickr.com/600/400/paris,girl/all',
//       thumbImage: 'https://loremflickr.com/1200/800/brazil,rio',
//       title: 'Image 3',
//       alt: 'Image 3'
//     }, {
//       image: 'https://loremflickr.com/600/400/brazil,rio',
//       thumbImage: 'https://loremflickr.com/1200/800/brazil,rio',
//       title: 'Image 4',
//       alt: 'Image 4'
//     }, {
//       image: 'https://loremflickr.com/600/400/paris,girl/all',
//       thumbImage: 'https://loremflickr.com/1200/800/paris,girl/all',
//       title: 'Image 5',
//       alt: 'Image 5'
//     }, {
//       image: 'https://loremflickr.com/600/400/brazil,rio',
//       thumbImage: 'https://i.picsum.photos/id/609/400/350.jpg',
//       title: 'Image 6',
//       alt: 'Image 6'
//     }
// ];
}

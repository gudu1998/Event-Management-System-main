import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SlickCarouselModule } from 'ngx-slick-carousel'; 
import { DashboardRoutingModule } from './dashboard-routing.module';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NoticeComponent } from './notice/notice.component';
import { EventsComponent } from './events/events.component';
import { CollegeCampusComponent } from './college-campus/college-campus.component';
import { HomeComponent } from './home/home.component';
import { NgImageSliderModule } from 'ng-image-slider';
import { CreateEventComponent } from './events/create-event/create-event.component';
import { CreateNoticeComponent } from './notice/create-notice/create-notice.component';
import { JobComponent } from './job/job.component';
import { CreateJobComponent } from './job/create-job/create-job.component';
import { FindAluminiComponent } from './find-alumini/find-alumini.component';
import { ReactiveFormsModule } from '@angular/forms';
import { EventDetailComponent } from './events/event-detail/event-detail.component';
import { ListOfAluminiComponent } from './list-of-alumini/list-of-alumini.component';
import { GetAluminiByBranchNameBatchCollegeComponent } from './find-alumini/get-alumini-by-branch-name-batch-college/get-alumini-by-branch-name-batch-college.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { FindAluminiByFullNameComponent } from './list-of-alumini/find-alumini-by-full-name/find-alumini-by-full-name.component';
import {MultiSelectModule} from 'primeng/multiselect';
import { FormsModule } from '@angular/forms';
import {PaginatorModule} from 'primeng/paginator';
import {TableModule} from 'primeng/table';
import {CardModule} from 'primeng/card';
import {InputTextModule} from 'primeng/inputtext';
@NgModule({
  declarations: [
        HeaderComponent,
        FooterComponent,
        NoticeComponent,
        EventsComponent,
        CollegeCampusComponent,
        HomeComponent,
        CreateEventComponent,
        CreateNoticeComponent,
        JobComponent,
        CreateJobComponent,
        FindAluminiComponent,
        EventDetailComponent,
        ListOfAluminiComponent,
        GetAluminiByBranchNameBatchCollegeComponent,
        FindAluminiByFullNameComponent
        
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    SlickCarouselModule,
    NgImageSliderModule,
    ReactiveFormsModule,
    FormsModule,
    NgxPaginationModule,
    MultiSelectModule,
    PaginatorModule,
    TableModule,
    CardModule,
    InputTextModule
  ]
})
export class DashboardModule { }

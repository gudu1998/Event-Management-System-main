import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { takeWhile } from 'rxjs';

@Component({
  selector: 'app-notice',
  templateUrl: './notice.component.html',
  styleUrls: ['./notice.component.css']
})
export class NoticeComponent implements OnInit {
  noticeArray!: any;
  pageNumber: any = 1;
  count: any = 3;
  noticeActionIsActive: boolean = true;

  constructor(private shared:SharedService) { }

  ngOnInit(): void {
    this.shared.showNotice().pipe(takeWhile(() => this.noticeActionIsActive)).subscribe(res=>{
   this.noticeArray = res.result;
    })
  }

  ngOnDestroy() {
    this.noticeActionIsActive = false
  }
}

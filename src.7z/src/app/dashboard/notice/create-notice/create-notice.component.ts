import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedService } from '../../shared.service';
import {  takeWhile } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-notice',
  templateUrl: './create-notice.component.html',
  styleUrls: ['./create-notice.component.css']
})
export class CreateNoticeComponent implements OnInit {
  noticeForm!: FormGroup;
  noticeActionIsActive: boolean = true;

  constructor(private fb: FormBuilder,private shared:SharedService,private router:Router) { 
     this.noticeForm = this.fb.group({
      Title: [null, [Validators.required]],
      Description: [null, [Validators.required]],
      Date: [null, [Validators.required]]
    })

  }

  ngOnInit(): void {
  }

  createNotice(){
    this.shared.createNewNotice(this.noticeForm.value.Title,this.noticeForm.value.Description,this.noticeForm.value.Date)
    .pipe(takeWhile(() => this.noticeActionIsActive)).subscribe(result => {
     this.router.navigate(['/user/notice'])
    })
  }

  ngOnDestroy() {
    this.noticeActionIsActive = false
  }
}

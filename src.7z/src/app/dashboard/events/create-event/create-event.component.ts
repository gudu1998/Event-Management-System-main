import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedService } from '../../shared.service';
import { takeWhile } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css']
})
export class CreateEventComponent implements OnInit {
  eventForm!: FormGroup;

  eventType = ['Educational Event','Sports Event','Social'];
  eventCategory = ['Workshop','Hackathon','Cultural'];
  eventAmPm=['AM','PM']
  eventTimeZone=['US (UTC-8)','UK (UTC-0)']
  eventActionIsActive: boolean = true;
  constructor(private fb: FormBuilder,private shared:SharedService,private router:Router) { 

    this.eventForm = this.fb.group({
      Type: [null, [Validators.required]],
      Category: [null, [Validators.required]],
      Title: [null, [Validators.required]],
      Description: [null, [Validators.required]],
      Url: [null, [Validators.required]],
      Date: [null, [Validators.required]],
      Time: [null, [Validators.required]],
      TimeAmPm: [null, [Validators.required]],
      TimeZone: [null, [Validators.required]],
      Image: [null, [Validators.required]]
    })

  }

  ngOnInit(): void {
  }

  onFileSelect($event:any) {
    const file:File = $event.target.files[0]
    this.eventForm.patchValue({ Image: file });
  }
  createEvent(){
    this.shared.createNewEvent(this.eventForm.value.Type,this.eventForm.value.Category,this.eventForm.value.Title,
      this.eventForm.value.Description,this.eventForm.value.Url,this.eventForm.value.Date,this.eventForm.value.Time,
      this.eventForm.value.TimeAmPm,this.eventForm.value.TimeZone,this.eventForm.value.Image)
      .pipe(takeWhile(() => this.eventActionIsActive)).subscribe(result => {
        this.router.navigate(['/user/events'])
      })
  }
  ngOnDestroy() {
    this.eventActionIsActive = false
  }



}

import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

import { takeWhile } from 'rxjs';
@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {
  public eventArray:any;
  constructor(private shared:SharedService) { }
  pageNumber: any = 1;
  count: any = 3;
  eventActionIsActive:boolean = true;
  
  ngOnInit(): void {
    this.shared.showEvent().pipe(takeWhile(() => this.eventActionIsActive)).subscribe(res=>{
      this.eventArray = res.result;
      console.log(this.eventArray)
       })

       
  }

  ngOnDestroy() {
    this.eventActionIsActive = false
  }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from '../../shared.service';
import { takeWhile } from 'rxjs';

@Component({
  selector: 'app-event-detail',
  templateUrl: './event-detail.component.html',
  styleUrls: ['./event-detail.component.css']
})
export class EventDetailComponent implements OnInit {
  eventDetail:any;
  eventActionIsActive:boolean = true;
  constructor(private route: ActivatedRoute,private shared:SharedService) { }

  ngOnInit(): void {
    const {id} = this.route.snapshot.params;
 this.shared.getEventDetails(id).pipe(takeWhile(() => this.eventActionIsActive)).subscribe(res => {
  this.eventDetail= res.result;
});
  }

  ngOnDestroy() {
    this.eventActionIsActive = false
  }

}

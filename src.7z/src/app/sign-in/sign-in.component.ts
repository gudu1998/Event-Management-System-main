import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SharedService } from '../dashboard/shared.service';
import {  catchError, of, takeWhile } from 'rxjs';


@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
  loginForm: FormGroup;
  signInActionisActive: boolean = true;
  error:boolean = false;
  errorMessage:any;

  constructor(private fb: FormBuilder,private router:Router,private shared:SharedService) {
    this.loginForm = this.fb.group({
      Username: [null, [Validators.required]],
      Mobilenumber: [null, [Validators.required]],
      Password: [null, [Validators.required]]
    })
  }
   

  ngOnInit(): void {
  }

  navigateToSignUpPage(){
    this.router.navigate(['/user/signup'])
  }

  loginFormSubmit(){
    this.shared.loginAlumini(this.loginForm.value.Username,this.loginForm.value.Mobilenumber,
      this.loginForm.value.Password)
      .pipe(catchError(e => of(e.error)))
    .subscribe(res => {
      if(res.status != 200){
        this.error=true;
        this.errorMessage = res.message
      }
      else
      this.router.navigate(['/user/home'])   
    })
  }

  ngOnDestroy() {
    this.signInActionisActive = false
  }
}

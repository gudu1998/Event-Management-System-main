import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseUrl = 'http://localhost:5000';
  constructor(private http: HttpClient) { }

  createUser(fullName: String, userName: String, biography: String,
    branch: String, college: String, email: String,
    age: Number, address: String, city: String,
    state: String, country: String, mobile: Number,
    batchYear: Number, password: String): Observable<any>{

    // const aluminiData: any = new FormData();

    // aluminiData.append("fullName", fullName);
    // aluminiData.append("userName", userName);
    // aluminiData.append("biography", biography);
    // aluminiData.append("branch", branch);
    // aluminiData.append("college", college);
    // aluminiData.append("email", email);
    // aluminiData.append("age", age);
    // aluminiData.append("address", address);
    // aluminiData.append("city", city);
    // aluminiData.append("state", state);
    // aluminiData.append("country", country);
    // aluminiData.append("mobile", mobile);
    // aluminiData.append("batchYear", batchYear);
    // aluminiData.append("password", password);

  const aluminiData = {fullName, userName, biography,
    branch, college, email,
    age, address, city,
    state, country, mobile,
    batchYear, password}
    return this.http.post(this.baseUrl + '/createUser', aluminiData);
  }


}

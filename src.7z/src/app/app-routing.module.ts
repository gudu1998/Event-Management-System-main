import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateComponent } from './create/create.component';


import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';

const routes: Routes = [
  { path: 'user/create', component: CreateComponent },
  { path: 'user/signin', component: SignInComponent },
  { path: 'user/signup', component: SignUpComponent },
  {path:'user',loadChildren:()=>import('./dashboard/dashboard.module')
  .then(m=>m.DashboardModule)},
  {path: '**', redirectTo: '/user/create', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
